﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MainMenu : MonoBehaviour
{

    public GameObject settingsPanel;

    public void startGame(){
        SceneManager.LoadScene(1);
    }

    public void openSettings(){ 
        settingsPanel.SetActive(true);
    }

    public void closeSettings(){
        settingsPanel.SetActive(false);
    }

    public void exitGame(){
        Debug.Log("Quit");
        Application.Quit();
    }


}
